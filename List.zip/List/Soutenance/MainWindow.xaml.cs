﻿using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Soutenance
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            TcpListener listener = new TcpListener(IPAddress.Parse("127.0.0.1"), 11111);
            listener.Start();

            Console.WriteLine("Attente de connexion...");

            TcpClient client = listener.AcceptTcpClient();
            Console.WriteLine("Client connecté!");

            NetworkStream stream = client.GetStream();

            byte[] messageReceived = new byte[1024];

            int byteRecv = stream.Read(messageReceived, 0, messageReceived.Length);

            Console.WriteLine("Message du Serveur -> {0}", Encoding.ASCII.GetString(messageReceived, 0, byteRecv));

            client.Close();
            listener.Stop();
        }
    }
}