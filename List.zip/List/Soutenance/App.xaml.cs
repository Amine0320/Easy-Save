﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Soutenance
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
